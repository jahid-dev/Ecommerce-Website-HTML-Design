$(document).ready(function(){
	$('#menu').slicknav();
	
	$(".select-option").click(function(){
        $(".doller").toggleClass('doller-show');
    });
    
	$(".carrancy-click").click(function(){
        $(".all-carrancy").toggleClass('all-carrancy-block');
    });

    $(".banner").on('translate.owl.carousel', function () {
            $('.slider-text h1').removeClass('slideInLeft animated').hide();
            $('.slider-text h4').removeClass('slideInLeft animated').hide();
            $('.slider-text p').removeClass('slideInLeft animated').hide();
            $('.slider-text a').removeClass('slideInLeft animated').hide();
        });
    $(".banner").on('translated.owl.carousel', function () {
        $('.owl-item.active .slider-text h1').addClass('slideInLeft animated').show();
        $('.owl-item.active .slider-text h4').addClass('slideInLeft animated').show();
        $('.owl-item.active .slider-text p').addClass('slideInLeft animated').show();
        $('.owl-item.active .slider-text a').addClass('slideInLeft animated').show();
    });

    $('.banner').owlCarousel({
	    loop:true,
	    margin:10,
	    autoplay: true,
		smartSpeed:1000,
	    nav:true,
	    dots: false,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:1
	        },
	        1000:{
	            items:1
	        }
	    }
	});
    $('.all-footware').owlCarousel({
	    loop:true,
	    margin:0,
	    autoplay: true,
		smartSpeed:1000,
	    nav:true,
	    dots: false,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:4
	        }
	    }
	});
    $('.all-rated-products').owlCarousel({
	    loop:true,
	    margin:0,
	    autoplay: true,
		smartSpeed:1000,
	    nav:true,
	    dots: false,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:3
	        }
	    }
	});
    $('.all-blog').owlCarousel({
	    loop:true,
	    margin:0,
	    autoplay: true,
		smartSpeed:1000,
	    nav:true,
	    dots: false,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:2
	        }
	    }
	});
    $('.sb-all-product').owlCarousel({
	    loop:true,
	    margin:0,
	    autoplay: false,
		smartSpeed:1000,
	    nav:true,
	    dots: false,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:1
	        }
	    }
	});
    $('.client-logo').owlCarousel({
	    loop:true,
	    margin:0,
	    autoplay: true,
		smartSpeed:1000,
	    nav:false,
	    dots: false,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:3
	        },
	        1000:{
	            items:6
	        }
	    }
	});
    $('.all-tastimonial').owlCarousel({
	    loop:true,
	    margin:0,
	    autoplay: true,
		smartSpeed:1000,
	    nav:false,
	    dots: true,
	    responsive:{
	        0:{
	            items:1
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:1
	        }
	    }
	});
    $('.xzoom-thumbs').owlCarousel({
	    loop:true,
	    margin:10,
	    autoplay: true,
		smartSpeed:1000,
	    nav:false,
	    dots: true,
	    responsive:{
	        0:{
	            items:2
	        },
	        600:{
	            items:2
	        },
	        1000:{
	            items:4
	        }
	    }
	});

});